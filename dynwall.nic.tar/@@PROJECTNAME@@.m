#define kBundlePath @"/Library/WallpaperLoader/@@PROJECTNAME@@.bundle"
